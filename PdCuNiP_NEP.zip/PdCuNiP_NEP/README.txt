Notes (please refer to https://gpumd.org/nep/index.html):
1. nep.in: This file specifies hyperparameters used for training neuroevolution potential (NEP) models.
2. nep.population160.generation1013200.txt: NEP potential parameters (file).
3. nep.restart: restart file.
4. test.xyz: testing dataset.
5. train.xyz: training dataset.
